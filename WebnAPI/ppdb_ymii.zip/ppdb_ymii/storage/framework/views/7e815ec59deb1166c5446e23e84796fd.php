<!-- plugin for charts  -->
<script src="<?php echo e(asset('assets/js/plugins/chartjs.min.js')); ?>"></script>
<!-- plugin for scrollbar  -->
<script src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>


<!-- github button -->
<script src="https://buttons.github.io/buttons.js"></script>
<!-- main script file  -->
<script src="<?php echo e(asset('assets/js/soft-ui-dashboard-tailwind.js?v=1.0.5')); ?>"></script>
<?php /**PATH /home/hudzaifah/Documents/Tugas IDN/UAS_SMT2/WebnAPI/ppdb_ymii/resources/views/scripts/scripts.blade.php ENDPATH**/ ?>