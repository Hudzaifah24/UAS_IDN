<script src="https://cdn.tailwindcss.com"></script>

<?php /**PATH /home/hudzaifah/Documents/Tugas IDN/UAS_SMT2/WebnAPI/ppdb_ymii/resources/views/scripts/styles.blade.php ENDPATH**/ ?>