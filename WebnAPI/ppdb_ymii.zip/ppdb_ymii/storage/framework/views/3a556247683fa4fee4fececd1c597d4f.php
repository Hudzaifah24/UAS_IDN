<?php echo e($slot); ?>

<?php /**PATH /home/hudzaifah/Documents/Tugas IDN/UAS_SMT2/WebnAPI/ppdb_ymii/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>