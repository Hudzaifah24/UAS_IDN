<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/hudzaifah/Documents/Tugas IDN/UAS_SMT2/WebnAPI/ppdb_ymii/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>