<script src="https://cdn.tailwindcss.com"></script>

<?php /**PATH /home/hudzaifah/Project/ppdb_ymii/resources/views/scripts/styles.blade.php ENDPATH**/ ?>