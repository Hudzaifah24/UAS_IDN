<?php echo e($slot); ?>

<?php /**PATH /home/hudzaifah/Project/ppdb_ymii/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>